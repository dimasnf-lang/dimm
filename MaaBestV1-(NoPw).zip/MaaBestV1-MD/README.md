## SCRIPT BY RAMAA GNNZ
Record : Ramaa gnnz
author : Lexxy ofc

## THANKS TO
   •Allah Swt
   •Ortu
   •Ramaa gnnz (Creator)
   •Lexxy Ofc (Penyedia Base)
   •Zeeone Ofc (Penyedia apikey)
   •Nata gnz (Penyedia Apikey)
   •Ronzz YT (Support)
   •${setting.ownerName}
   •And My Subscriber 

---

## Informasi
Scrip MaaBest-MdV1 Menggunakan Base dari Lexxy official kemudian dikembalikan oleh Ramaa Gnnz

## YouTube Ramaa
- [Link yt](https://youtube.com/@ramaagnnz961?si=EnSIkaIECMiOmarE)

<p align="center">
<a href="https://youtube.com/@ramaagnnz961?si=EnSIkaIECMiOmarE"><img src="https://telegra.ph/file/bbabc9951ac56bea354b9.jpg" />
</p>

## Contact WhatsApp 
- [WhatsApp Admin](https://wa.me/6285791220179)

<p align="center">
<a href="https://wa.me/6285791220179"><img src="https://telegra.ph/file/bbabc9951ac56bea354b9.jpg" />
</p>

## Command Termux
$ pkg update && pkg upgrade
$ pkg install nodejs
$ pkg install ffmpeg 
$ pkg install libwebp 
$ pkg install imagemagick 
$ pkg install benang
$ termux-setup-storage
$ cd /sdcard
$ cd (Nama File)
$ npm install 
$npm start

Jika ada Yang Eror Lagu Chat 👇
WhatsApp: https://wa.me/6285791220179

## Heroku Buildpack
```bash
heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## Donate
- [Qris all pay](https://telegra.ph/file/01ad28fe8c110ce351f8a.jpg)
- [Saweria](https://saweria.co/Ramaa1)

Terimakasih yang sudah donasi 🙏.

# Official Group
<a href="https://chat.whatsapp.com/JYjwm7vfjdB69FrnyuwoEF"><img src="https://img.shields.io/badge/Alphabot Support-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />



