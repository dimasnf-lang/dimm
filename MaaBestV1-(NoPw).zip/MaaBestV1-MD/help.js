
exports.infoOwner = () =>{
return`──「 *DATA PROFIL OWNER* 」──

 ⬣ *Nama :* Vynzz 
 ⬣ *Umur :* 14
 ⬣ *Hoby. :* Turu/Game
 ⬣ *Asal   :* Jabar - Majalengka
 ⬣ *Status:* Manusia Biasa
 ⬣ *Zodiak:* Gk tau

                  「 *SOSIAL MEDIA*」
 ⬣ *Whatsapp:* 083121306468
 ⬣ *Youtube:* VynzzOfc (@vynzz01)
 ⬣ *Github:* ---
 ⬣ *Tiktok:* @harrrx4
 ⬣ *Instagram:* @harrzzx02
 `
}